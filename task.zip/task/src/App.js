import React, { useState, useEffect } from "react";
import { Button, Modal } from "react-bootstrap";
import Header from "./header";
import Footer from "./footer";
import Api from "./Api";
import "./App.css";

const App = () => {
  const [data, setData] = useState([]);
  const [eventData, setEventData] = useState("");
  const [showDialog, setShowDialog] = useState(false);

  const handleClose = () => setShowDialog(false);

  useEffect(() => {
    Api.get("/history")
      .then((response) => {
        if (response.status === 200) {
          setData(response.data);
          setTimeout(() => {
            document.body.classList.add("loaded");
          }, 2000);
        }
      })
      .catch((err) => {
        alert(err.message);
      });
  }, []);

  const getEventById = (id) => {
    Api.get(`/history/${id}`)
      .then((response) => {
        if (response.status === 200) {
          setEventData(response.data);
        }
      })
      .catch((err) => {
        alert(err.message);
      });
    setShowDialog(true);
  };
  return (
    <div className="App">
      <div id="loader-wrapper">
        <div id="loader"></div>
        <div className="loader-section section-left"></div>
        <div className="loader-section section-right"></div>
      </div>
      <Header />
      <div className="container-fluid tm-container-content tm-mt-60">
        <div className="row mb-4">
          <h2 className="col-6 tm-text-primary">Historical Events</h2>
        </div>
        <div className="row tm-mb-90 tm-gallery main-block">
          {data.map((item, i) => {
            return (
              <div
                className="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12 mb-5 blocks"
                key={i}
              >
                <div className="inner-block">
                  <div className="d-flex justify-content-between">
                    <span className="tm-text-black">
                      Event: <span className="tm-text-gray">{item.title}</span>
                    </span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <span className="tm-text-black">
                      Event Date:{" "}
                      <span className="tm-text-gray">
                        {item.event_date_utc}
                      </span>
                    </span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <span className="tm-text-black">
                      Flight Number:{" "}
                      <span className="tm-text-gray">
                        {item.flight_number ? item.flight_number : "NA"}
                      </span>
                    </span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <Button
                      variant="primary"
                      onClick={() => getEventById(item.id)}
                      style={{ marginTop: "1em" }}
                    >
                      Click for details
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <Footer />
      <>
        <Modal
          show={showDialog}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>{eventData.title}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="d-flex justify-content-between">
              <span className="tm-text-black">
                Details:{" "}
                <span className="tm-text-gray link">{eventData.details}</span>
              </span>
            </div>
            <div className="d-flex justify-content-between">
              <span className="tm-text-black">
                Article:{" "}
                <span className="tm-text-gray link">
                  <a href={eventData.links?.article}>
                    {eventData.links?.article}
                  </a>
                </span>
              </span>
            </div>
            <div className="d-flex justify-content-between">
              <span className="tm-text-black">
                Wikipedia:{" "}
                <span className="tm-text-gray link">
                  {" "}
                  <a href={eventData.links?.wikipedia}>
                    {eventData.links?.wikipedia}
                  </a>
                </span>
              </span>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    </div>
  );
};
export default App;
