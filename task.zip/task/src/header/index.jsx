const Header = () => {
  return (
    <nav className="navbar navbar-expand-lg">
      <div className="container-fluid">
        <a className="navbar-brand" href="#">
          <i className="fas fa-rocket mr-2"></i>
          SpaceX
        </a>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav ml-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <a className="nav-link nav-link-1 active" aria-current="page">
                Home
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
export default Header;
